# -*- coding: utf-8 -*-

# https://www.python.org/dev/peps/pep-0440/#examples-of-compliant-version-schemes
__version__ = '0.12.1'

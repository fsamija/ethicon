# -*- coding: utf-8 -*-
from django.contrib.auth.models import AbstractUser

class TestUser(AbstractUser):
    pass

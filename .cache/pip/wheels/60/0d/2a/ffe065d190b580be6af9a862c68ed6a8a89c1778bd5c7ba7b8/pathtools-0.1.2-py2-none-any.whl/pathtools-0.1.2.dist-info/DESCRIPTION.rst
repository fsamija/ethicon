pathtools
=========

Pattern matching and various utilities for file systems paths.





class BucketAlreadyExists(Exception):
    pass

from .models import dynamodb_backend
mock_dynamodb = dynamodb_backend.decorator

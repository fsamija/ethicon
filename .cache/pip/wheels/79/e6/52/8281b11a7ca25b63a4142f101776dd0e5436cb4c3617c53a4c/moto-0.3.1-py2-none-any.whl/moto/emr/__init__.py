from .models import emr_backend
mock_emr = emr_backend.decorator

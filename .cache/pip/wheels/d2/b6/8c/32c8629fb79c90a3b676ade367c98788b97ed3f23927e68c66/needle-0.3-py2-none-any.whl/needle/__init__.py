__version__ = '0.3'
__author__ = 'Ben Firshman'
__contact__ = 'ben@firshman.co.uk'
__homepage__ = 'https://github.com/bfirsh/needle'


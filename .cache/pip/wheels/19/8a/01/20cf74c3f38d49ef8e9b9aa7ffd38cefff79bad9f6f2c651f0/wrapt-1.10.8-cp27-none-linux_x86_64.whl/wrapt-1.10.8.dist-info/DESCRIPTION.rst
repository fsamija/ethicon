wrapt
=====

|Travis| |Coveralls| |PyPI|

A Python module for decorators, wrappers and monkey patching.

For full documentation see:

  http://wrapt.readthedocs.org

.. |Travis| image:: https://img.shields.io/travis/GrahamDumpleton/wrapt/develop.svg?style=plastic
   :target: https://travis-ci.org/GrahamDumpleton/wrapt?branch=develop
.. |Coveralls| image:: https://img.shields.io/coveralls/GrahamDumpleton/wrapt/develop.svg?style=plastic
   :target: https://coveralls.io/github/GrahamDumpleton/wrapt?branch=develop
.. |PyPI| image:: https://img.shields.io/pypi/v/wrapt.svg?style=plastic
   :target: https://pypi.python.org/pypi/wrapt



"""
edx-organizations app initialization module
"""
__version__ = '0.4.1'  # pragma: no cover

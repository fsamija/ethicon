"""
Mock implementations of remote dependencies for test isolation
"""

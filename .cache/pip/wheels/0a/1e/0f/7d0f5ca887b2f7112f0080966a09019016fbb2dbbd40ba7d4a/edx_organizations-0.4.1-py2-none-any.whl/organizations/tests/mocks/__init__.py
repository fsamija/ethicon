""" edx-organizations tests mocks initialization module """
